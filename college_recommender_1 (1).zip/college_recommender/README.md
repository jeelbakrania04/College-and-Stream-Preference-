# College Preference AI Dashboard

## What this app does
A single Streamlit app with three tabs:

1. **🎯 Recommend for Me** — enter your age, 12th score, and gender. The app
   finds past students with the closest profile (via k-nearest-neighbors on
   age + score, with a small boost for matching gender) and recommends
   colleges + streams based on what those similar students prioritized.
2. **📊 Analysis** — priority distribution and most popular colleges, across
   all students.
3. **🗂 Raw Data** — the full preferences table.

## Before you run it — fix this first
Your `Students` table needs columns for **age**, **gender**, and **12th
score** for the recommender to work. Open `recommender/engine.py` and edit
these three lines to match your real column names:

```python
STUDENT_AGE_COL = "age"
STUDENT_GENDER_COL = "gender"
STUDENT_SCORE_COL = "twelfth_score"
```

If your `Students` table doesn't have these columns yet, add them, e.g.:

```sql
ALTER TABLE testschema.Students
    ADD COLUMN age INT,
    ADD COLUMN gender VARCHAR(10),
    ADD COLUMN twelfth_score NUMERIC(5,2);
```

...and populate them for existing students. The more students have this
data filled in, the better the recommendations will be — it's a
"students like you" matcher, so it needs enough similar students to learn
from.

## Setup

```bash
pip install -r requirements.txt
```

Edit `config/settings.py` with your real Postgres credentials (don't commit
real passwords to git — consider using environment variables instead).

## Run

```bash
streamlit run app.py
```

## Project structure

```
college_recommender/
├── app.py                  # Streamlit entry point (all 3 tabs)
├── config/
│   └── settings.py         # DB connection settings
├── database/
│   └── connector.py        # SQLAlchemy connector, fetch_data()
├── analysis/
│   └── analyzer.py         # PreferenceAnalyzer: priority + popularity charts
└── recommender/
    ├── recommender.py      # Simple popularity-based top combos (no profile)
    └── engine.py           # ProfileRecommender: the age/score/gender matcher
```

## Notes / limitations
- This is a similarity-based heuristic, not an eligibility checker — there's
  no cutoff data, so it can't tell you if you'd actually get in anywhere.
  It only reflects what similar students *chose*.
- Recommendation quality depends entirely on how much historical preference
  + profile data you have. With very few students, results will look thin.
- If you later get real eligibility/cutoff data per college+stream (and
  optionally gender-based quotas), that would let us build a second,
  much more accurate "Am I eligible" mode alongside this one — worth
  revisiting once that data exists.

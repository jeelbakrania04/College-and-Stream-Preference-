import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from database.connector import DatabaseConnector


class PreferenceAnalyzer:
    def __init__(self):
        self.connector = DatabaseConnector()

    def load_preferences(self) -> pd.DataFrame:
        query = """
        SELECT s.name, c.college_name, st.stream_name, p.priority
        FROM testschema.Preferences p
        JOIN testschema.Students s ON p.student_id = s.student_id
        JOIN testschema.Colleges c ON p.college_id = c.college_id
        JOIN testschema.Streams st ON p.stream_id = st.stream_id;
        """
        return self.connector.fetch_data(query)

    def priority_distribution_fig(self, df: pd.DataFrame):
        """Return a matplotlib figure: how many students chose each priority level"""
        fig, ax = plt.subplots(figsize=(6, 4))
        sns.countplot(x="priority", data=df, ax=ax)
        ax.set_title("Distribution of Student Preferences by Priority")
        return fig

    def top_colleges_table(self, df: pd.DataFrame) -> pd.DataFrame:
        """Most popular colleges based on first priority"""
        return (
            df[df["priority"] == 1]
            .groupby("college_name")
            .size()
            .reset_index(name="count")
            .sort_values("count", ascending=False)
        )

    def college_popularity_fig(self, df: pd.DataFrame):
        top_colleges = self.top_colleges_table(df)
        fig, ax = plt.subplots(figsize=(8, 5))
        sns.barplot(x="count", y="college_name", data=top_colleges, ax=ax)
        ax.set_title("Top Colleges by First Priority")
        return fig

    def close(self):
        self.connector.close()

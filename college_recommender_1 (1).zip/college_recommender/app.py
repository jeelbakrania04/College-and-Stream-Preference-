import streamlit as st
import pandas as pd

from analysis.analyzer import PreferenceAnalyzer
from recommender.engine import ProfileRecommender


st.set_page_config(page_title="🎓 College Preferences AI", layout="wide")
st.title("🎓 Student College Preference Dashboard")


def _sanitize_bool_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Convert numpy.bool_ columns to native Python bool so Streamlit's
    frontend serialization doesn't choke on them."""
    for col in df.select_dtypes(include="bool").columns:
        df[col] = df[col].map(bool)
    return df


@st.cache_data(ttl=300)
def get_preferences_df() -> pd.DataFrame:
    analyzer = PreferenceAnalyzer()
    try:
        df = analyzer.load_preferences()
    finally:
        analyzer.close()
    return _sanitize_bool_columns(df)


@st.cache_data(ttl=300)
def get_engine_df() -> pd.DataFrame:
    engine = ProfileRecommender()
    try:
        df = engine.load_data()
    finally:
        engine.close()
    return _sanitize_bool_columns(df)


tab1, tab2, tab3 = st.tabs(["🎯 Recommend for Me", "📊 Analysis", "🗂 Raw Data"])

# --- Tab 1: Recommend for Me -------------------------------------------------
with tab1:
    st.subheader("Tell us about yourself")
    st.caption(
        "We don't have official eligibility/cutoff data, so this finds past "
        "students with a similar profile to you and shows what they chose. "
        "Treat it as a starting point, not a guarantee of admission."
    )

    with st.form("student_profile_form"):
        col_a, col_b, col_c = st.columns(3)
        with col_a:
            age = st.number_input("Age", min_value=14, max_value=25, value=18, step=1)
        with col_b:
            score = st.number_input(
                "12th Score (%)", min_value=0.0, max_value=100.0, value=75.0, step=0.5
            )
        with col_c:
            gender = st.selectbox("Gender", ["Male", "Female", "Other"])

        top_n = st.slider("How many colleges to recommend?", min_value=3, max_value=10, value=5)
        submitted = st.form_submit_button("Get Recommendations")

    if submitted:
        try:
            engine_df = get_engine_df()
            engine = ProfileRecommender()
            recs = engine.recommend(
                age=age, score=score, gender=gender, df=engine_df, top_n_colleges=top_n
            )

            if recs.empty:
                st.warning("No similar past students found to base a recommendation on.")
            else:
                st.success(f"Based on students similar to you, here are your top {top_n} colleges:")
                for college in recs["college_name"].cat.categories:
                    college_rows = recs[recs["college_name"] == college]
                    if college_rows.empty:
                        continue
                    with st.expander(f"🏫 {college}", expanded=True):
                        st.write("Recommended streams at this college, best match first:")
                        st.table(
                            college_rows[["stream_name", "match_score"]]
                            .rename(columns={"stream_name": "Stream", "match_score": "Match Score"})
                            .reset_index(drop=True)
                        )
        except Exception as e:
            st.error(
                "Couldn't generate recommendations. This is often because the "
                "STUDENT_AGE_COL / STUDENT_GENDER_COL / STUDENT_SCORE_COL "
                f"constants in recommender/engine.py don't match your real "
                f"Students table column names.\n\nError: {e}"
            )

# --- Tab 2: Analysis ---------------------------------------------------------
with tab2:
    try:
        df = get_preferences_df()

        st.subheader("Priority Distribution")
        analyzer = PreferenceAnalyzer()
        st.pyplot(analyzer.priority_distribution_fig(df))

        st.subheader("Top Colleges by First Priority")
        st.pyplot(analyzer.college_popularity_fig(df))
    except Exception as e:
        st.error(f"Couldn't load analysis: {e}")

# --- Tab 3: Raw Data ----------------------------------------------------------
with tab3:
    st.subheader("Full Preferences Data")
    try:
        st.dataframe(get_preferences_df(), hide_index=True)
    except Exception as e:
        st.error(f"Couldn't load data: {e}")

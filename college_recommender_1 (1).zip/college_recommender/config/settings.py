# config/settings.py
# Database configuration
DB_NAME = "testdb"
DB_USER = "postgres"
DB_PASSWORD = "system"
DB_HOST = "localhost"
DB_PORT = "5432"

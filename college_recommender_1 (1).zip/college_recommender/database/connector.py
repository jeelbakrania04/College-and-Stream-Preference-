import pandas as pd
from sqlalchemy import create_engine
from config import settings


class DatabaseConnector:
    def __init__(self):
        # Build SQLAlchemy engine string
        self.engine = create_engine(
            f"postgresql+psycopg2://{settings.DB_USER}:{settings.DB_PASSWORD}"
            f"@{settings.DB_HOST}:{settings.DB_PORT}/{settings.DB_NAME}"
        )

    def fetch_data(self, query: str) -> pd.DataFrame:
        """Run a SQL query and return results as a DataFrame"""
        return pd.read_sql(query, self.engine)

    def close(self):
        """Dispose of the engine"""
        self.engine.dispose()

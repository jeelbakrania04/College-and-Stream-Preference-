"""
Profile-based recommender.

Since we don't have eligibility/cutoff data, this recommends colleges and
streams using a "students like you" approach:

  1. Pull every past student's profile (age, gender, 12th score) together
     with what they chose (college, stream, priority).
  2. Find the K past students whose profile is numerically closest to the
     new student's (age, score), giving a small extra boost to students who
     share the same gender.
  3. Aggregate what those similar students picked, weighted by how high a
     priority they gave it, into a ranked list of college/stream combos.

This is a pattern-matching heuristic, not a guarantee of eligibility -- it
tells you what similar students tended to choose, not whether you'll be
admitted.
"""

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors

from database.connector import DatabaseConnector

# --------------------------------------------------------------------------
# IMPORTANT: edit these three names to match your actual Students table
# columns. They are not part of the original schema shown to me, so these
# are placeholders -- the app will raise a clear error if they're wrong.
# --------------------------------------------------------------------------
STUDENT_AGE_COL = "age"
STUDENT_GENDER_COL = "gender"
STUDENT_SCORE_COL = "twelfth_score"
# --------------------------------------------------------------------------

# How much weight a priority-1 / priority-2 / priority-3 choice contributes
# when tallying up what "similar" students picked. Anything not listed here
# falls back to 0.5. Extend this if your data has more than 3 priorities.
PRIORITY_WEIGHTS = {1: 3.0, 2: 2.0, 3: 1.0}


class ProfileRecommender:
    def __init__(self):
        self.connector = DatabaseConnector()

    def load_data(self) -> pd.DataFrame:
        query = f"""
        SELECT
            s.student_id,
            s.name,
            s.{STUDENT_AGE_COL}    AS age,
            s.{STUDENT_GENDER_COL} AS gender,
            s.{STUDENT_SCORE_COL}  AS score,
            c.college_name,
            st.stream_name,
            p.priority
        FROM testschema.Preferences p
        JOIN testschema.Students s ON p.student_id = s.student_id
        JOIN testschema.Colleges c ON p.college_id = c.college_id
        JOIN testschema.Streams st ON p.stream_id = st.stream_id;
        """
        return self.connector.fetch_data(query)

    @staticmethod
    def _profile_table(df: pd.DataFrame) -> pd.DataFrame:
        return df[["student_id", "age", "gender", "score"]].drop_duplicates(
            "student_id"
        ).reset_index(drop=True)

    def recommend(
        self,
        age: float,
        score: float,
        gender: str,
        df: pd.DataFrame = None,
        top_n_colleges: int = 5,
        k_neighbors: int = 15,
    ) -> pd.DataFrame:
        """Return a DataFrame of [college_name, stream_name, match_score],
        sorted so the strongest college recommendations come first and,
        within each college, the strongest matching streams come first."""
        if df is None:
            df = self.load_data()
        if df.empty:
            return pd.DataFrame(columns=["college_name", "stream_name", "match_score"])

        profiles = self._profile_table(df)

        scaler = StandardScaler()
        numeric = scaler.fit_transform(profiles[["age", "score"]])
        query_point = scaler.transform([[age, score]])

        k = min(k_neighbors, len(profiles))
        nn = NearestNeighbors(n_neighbors=k)
        nn.fit(numeric)
        _, indices = nn.kneighbors(query_point)

        neighbor_ids = profiles.iloc[indices[0]]["student_id"].values
        neighbor_df = df[df["student_id"].isin(neighbor_ids)].copy()

        neighbor_df["gender_match"] = (
            neighbor_df["gender"].astype(str).str.lower() == str(gender).lower()
        ).astype(int)
        neighbor_df["weight"] = neighbor_df["priority"].map(PRIORITY_WEIGHTS).fillna(0.5)
        neighbor_df["weight"] *= 1 + 0.5 * neighbor_df["gender_match"]

        scored = (
            neighbor_df.groupby(["college_name", "stream_name"])["weight"]
            .sum()
            .reset_index(name="match_score")
        )

        top_colleges = (
            scored.groupby("college_name")["match_score"]
            .sum()
            .sort_values(ascending=False)
            .head(top_n_colleges)
            .index.tolist()
        )

        result = scored[scored["college_name"].isin(top_colleges)].copy()
        result["college_name"] = pd.Categorical(
            result["college_name"], categories=top_colleges, ordered=True
        )
        result = result.sort_values(
            ["college_name", "match_score"], ascending=[True, False]
        )
        return result.reset_index(drop=True)

    def close(self):
        self.connector.close()

import pandas as pd
from database.connector import DatabaseConnector


class Recommender:
    """Simple popularity-based recommender: which college+stream combos
    get picked as first priority most often, across all students."""

    def __init__(self):
        self.connector = DatabaseConnector()

    def load_preferences(self) -> pd.DataFrame:
        query = """
        SELECT s.name, c.college_name, st.stream_name, p.priority
        FROM testschema.Preferences p
        JOIN testschema.Students s ON p.student_id = s.student_id
        JOIN testschema.Colleges c ON p.college_id = c.college_id
        JOIN testschema.Streams st ON p.stream_id = st.stream_id;
        """
        return self.connector.fetch_data(query)

    def recommend_top_combos(self, df: pd.DataFrame, top_n: int = 5) -> pd.DataFrame:
        top_combo = (
            df[df["priority"] == 1]
            .groupby(["college_name", "stream_name"])
            .size()
            .reset_index(name="count")
            .sort_values("count", ascending=False)
        )
        return top_combo.head(top_n)

    def close(self):
        self.connector.close()
